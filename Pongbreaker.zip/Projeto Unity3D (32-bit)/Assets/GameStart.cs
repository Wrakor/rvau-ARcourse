﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Vuforia;
using UnityEngine.UI;

public class GameStart : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		StateManager sm = TrackerManager.Instance.GetStateManager ();
		IEnumerable<TrackableBehaviour> activeTrackables = sm.GetActiveTrackableBehaviours ();
		
		int size = 0;
		foreach (TrackableBehaviour tb in activeTrackables) {
			size++;
		}
		
		if (size > 0) {
			GameObject.Find ("Winner").GetComponent<Text> ().text = "Press Space to kick the ball!";
			Destroy (this);
		}
	}
}
